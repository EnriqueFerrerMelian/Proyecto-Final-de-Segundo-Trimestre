CREATE database Bar2;
drop table producto;
create table producto(
id int primary key auto_increment,
nombre varchar(20),
precio float
);
insert into producto (nombre, precio) values
("Cocamola", 2.00),
("Fantastica", 1.65),
("Spirite", 1.95),
("BlueBull", 2.40),
("Pepsu", 0.95),
("Dr. Dr", 1.30);
select * from producto;
select * from factura;

drop table factura;
create table factura (
id varchar(80) primary key,
mesa int
);
drop table pedidos;
create table pedidos(
mesa int,
factura varchar(80),
producto int,
cantidad int,
total double,
fecha date,
foreign key (factura) references factura (id),
foreign key (producto) references producto (id)
);
